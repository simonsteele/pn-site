// WTLWrapperTestView.h : interface of the CWTLWrapperTestView class
//
/////////////////////////////////////////////////////////////////////////////

#pragma once



class CWTLWrapperTestView : public CScintillaWindowImpl<CWTLWrapperTestView>
{
public:
	DECLARE_WND_CLASS(NULL)

	typedef CScintillaWindowImpl<CWTLWrapperTestView> baseClass;

	BOOL PreTranslateMessage(MSG* pMsg)
	{
		pMsg;
		return FALSE;
	}

	BEGIN_MSG_MAP(CWTLWrapperTestView)
		CHAIN_MSG_MAP(baseClass)
	END_MSG_MAP()

	int HandleNotify(LPARAM lParam)
	{
		return baseClass::HandleNotify(lParam);
	}

// Handler prototypes (uncomment arguments if needed):
//	LRESULT MessageHandler(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
//	LRESULT CommandHandler(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
//	LRESULT NotifyHandler(int /*idCtrl*/, LPNMHDR /*pnmh*/, BOOL& /*bHandled*/)
};
