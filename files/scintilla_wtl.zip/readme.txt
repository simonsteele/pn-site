C++ Scintilla Wrappers
======================

Scintilla is a fairly standard windowed control and these wrappers are also fairly 
simple - most of the code is automatically generated using python scripts which can be
downloaded from www.pnotepad.org/scintilla/. 

Last Built:
===========
Last refreshed against scintilla 1.49.