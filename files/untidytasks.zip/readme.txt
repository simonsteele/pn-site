Untidy.NAntTasks
================

Author: Simon Steele

Version: release 2

License: GPL

NAnt: http://nant.sourceforge.net/

Tasks:
versioninfo - Updates a VERSIONINFO block inside a .rc or .rc2 (or equivalent) file.
iscompiler - Calls the Inno Setup command-line compiler (or ISX/ISPP equivalents).
cvs - Simple CVS task. Checkout and update implemented (probably only partially).
mkssi - MKS Source Integrity Task.

Todo:
Extract documentation, re-document a couple of things, add sample files.