// VersionInfoTask - VersionInfo Updater Task for NAnt.
// Copyright (C) 2002 Simon Steele (untidy.net)
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using SourceForge.NAnt;
using SourceForge.NAnt.Attributes;

namespace Untidy.NAntTasks
{
	#region VersionInfo Class
	public class VersionInfo
	{
		public int major;
		public int minor;
		public int revision;
		public int build;

		public bool useCommas;

		public VersionInfo()
		{
			major = 1;
			minor = revision = build = 0;
			useCommas = false;
		}

		public override String ToString()
		{
			string res;

			if(useCommas)
			{
				res = string.Format("{0}, {1}, {2}, {3}", major, minor, revision, build);
			}
			else
			{
				res = string.Format("{0}.{1}.{2}.{3}", major, minor, revision, build);
			}

			return res;
		}
	}
	#endregion

	#region SimpleTextFile Class
	public class SimpleTextFile
	{
		private string filename = "";
		private	FileStream fs =	null;
		private	StreamWriter w = null;
		private	StreamReader r = null;
		
		public SimpleTextFile(string _filename)
		{
			filename = _filename;
		}

		public void Open()
		{
			Open(false);
		}

		public void	Open(bool bWrite)
		{
			if(filename == "")
				return;

			if(bWrite)
			{
				//if (logFile.Exists)
				//	File.Delete(filePath);

				fs = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite);
				w =	new	StreamWriter(fs);
				w.BaseStream.Seek(0, SeekOrigin.End);
			}
			else
			{
				FileInfo finfo = new FileInfo(filename);
				if (!finfo.Exists)
					return;

				fs = new FileStream(filename, FileMode.Open, FileAccess.Read);
				r = new StreamReader(fs);
				r.BaseStream.Seek(0, SeekOrigin.Begin);
			}
		}

		public void SeekStart()
		{
			fs.Seek(0, SeekOrigin.Begin);
		}

		public void	WriteLine(String input)	
		{
			if(w == null)
				return;

			w.WriteLine(input);
			w.Flush();
		}

		public string ReadLine() 
		{
			if(r == null)
				return "";

			StringBuilder output = new StringBuilder();
			output.Length =	0;

			if(r.Peek()	> -1) 
			{
				output.Append(r.ReadLine());
			}

			return output.ToString();
		}

		public void Close()
		{
			if(w != null)
				w.Close();

			if(r != null)
				r.Close();

			fs.Close();
			r = null;
			w = null;
			fs = null;
		}

		public bool	EOF()
		{
			if(r == null)
				return true;

			bool bEOF =	true;

			if(r.Peek()	> -1)
				bEOF = false;

			return bEOF;
		}
	}
	#endregion

	public delegate void UpdateFunction(SimpleTextFile infile, SimpleTextFile outfile, VersionInfo vi);

	/// <summary>
	/// VERSIONINFO Version Number Update Task
	/// </summary>
	/// <remarks>
	///   <para>This task can update a VERSIONINFO block inside 
	///   (for example) .rc or .rc2 files in order to increment/modify/replace 
	///   the version number inside.</para>
	///   <list type="bullet">
	///     <item>All parts of the version number can all be incremented/decremented/replaced.</item>
	///     <item>The entire version number can be replaced with a specific new value.</item>
	///     <item>The initial version number can be read from an external file with 
	///     a version number string in it (which can also be updated).</item>
	///     <item>Suffixes can be placed on the end of the version number strings for File or 
	///     Product entries.</item>
	///   </list>
	///   <note>All build numbers are assumed to be in the form major.minor.revision.build</note>
	///   <note>External build number files must include a number of the form 
	///   "[0-9]+.[0-9]+.[0-9]+.[0-9]+" on the first line, including the quotes.</note>
	/// </remarks>
	/// <example>
	///   <para>Increment the build number in <c>sample.rc</c>.</para>
	///   <code>&lt;versioninfo filename="sample.rc" /&gt;</code>
	///   <para>Load the version number from the file "build.number.file", increment the build 
	///   part and store it in both "myproduct.rc" and "build.number.file".</para>
	///   <code>&lt;versioninfo filename="myproduct.rc" source="build.number.file" /&gt;</code>
	///   <para>Increment the build part, and set the revision number to 13.</para>
	///   <code>&lt;versioninfo filename="myproduct.rc" setrevision="13" /&gt;</code>
	///   <para>Increment the minor part by 2, and don't increment the build part.</para>
	///   <code>&lt;versioninfo filename="myproduct.rc" minor="2" build="0" /&gt;</code>
	///   <para>Set the version number to 1.2.3.4.</para>
	///   <code>&lt;versioninfo filename="myproduct.rc" setversion="1.2.3.4" /&gt;</code>
	///   <para>Increment the build number by one, and add the suffix of "-devel" to the 
	///   ProductVersion string entry. This line only modifies the ProductVersion entries.</para>
	///   <code>&lt;versioninfo filename="myproduct.rc" productsuffix="-devel" update="ProductVersion" /&gt;</code>
	/// </example>
	[TaskName("versioninfo")]
	public class VersionInfoTask : Task
	{
		enum VersionSource
		{
			FileVersion = 0,
			ProductVersion = 1,
			FileVersionString = 2,
			ProductVersionString = 3,
			File = 4
		}

		enum UpdateTypes
		{
			FileVersion,
			ProductVersion,
			Both
		}

		enum VISetBits
		{
			Major = 1,
			Minor = 2,
			Revision = 4,
			Build = 8
		}

		#region Private Members

		private VersionSource _source = VersionSource.FileVersion;
		private UpdateTypes _target = UpdateTypes.Both;
		private int _setMask = 0;
		private VersionInfo _incNumbers = new VersionInfo();
		private VersionInfo _setNumbers = new VersionInfo();
		private bool _setVersionNum = false;
		private string _newVersionNum;
		private string _productSuffix = "";
		private string _fileSuffix = "";
		
		private string _fileName;
		private string _sourceFile;

		// These are the regular expressions used to match different types of version number string.
		Regex reSetVersionStr = new Regex("(?<a>[0-9]+)[\\.,](?<b>[0-9]+)[\\.,](?<c>[0-9]+)[\\.,](?<d>[0-9]+)");
		Regex reCustomFileVersion = new Regex("(\")(?<a>[0-9]+)[\\.,](?<b>[0-9]+)[\\.,](?<c>[0-9]+)[\\.,](?<d>[0-9]+)(?<end>\")");
		Regex reFileVersion = new Regex("(FILEVERSION )((?<a>[0-9]+),[ ]*(?<b>[0-9]+),[ ]*(?<c>[0-9]+),[ ]*(?<d>[0-9]+))");
		Regex reProductVersion = new Regex("(PRODUCTVERSION )((?<a>[0-9]+),[ ]*(?<b>[0-9]+),[ ]*(?<c>[0-9]+),[ ]*(?<d>[0-9]+))");
		Regex reFileVersionS = new Regex("(VALUE \"FileVersion\", \")((?<a>[0-9]+)[\\.,](?<b>[0-9]+)[\\.,](?<c>[0-9]+)[\\.,](?<d>[0-9]+))(?<end>\")");
		Regex reFileVersionS2 = new Regex("(VALUE \"FileVersion\", \")([a-zA-Z0-9-_\\.,]+)(?<end>\")");
		Regex reProductVersionS = new Regex("(VALUE \"ProductVersion\", \")((?<a>[0-9]+)[\\.,](?<b>[0-9]+)[\\.,](?<c>[0-9]+)[\\.,](?<d>[0-9]+))(?<end>\")");
		Regex reProductVersionS2 = new Regex("(VALUE \"ProductVersion\", \")([a-zA-Z0-9-_\\.,]+)(?<end>\")");

		#endregion

		#region Task Attributes
		/// <summary>
		/// Filename (*.rc or *.rc2) of the file to update.
		/// </summary>
		/// <remarks>
		/// If the source attribute is set to anything but File, the current version
		/// number will be read from the VERSIONINFO block in this file, modified, 
		/// and then written back.
		/// </remarks>
		[TaskAttribute("filename", Required=true)]
		public string FileName
		{
			get { return _fileName; }
			set { _fileName = value; }
		}

		/// <summary>
		/// This attribute sets which version number should be used as the original.
		/// </summary>
		/// <remarks>
		/// There are potentially four different version numbers in a VERSIONINFO block, 
		/// and each can be selected here. Alternatively, the value "File" will cause
		/// the version to be read from a separate file. See the "sourcefile" attribute.
		/// This attribute can take one of the following values: FileVersion, ProductVersion, 
		/// FileVersionString, ProductVersionString, File. Defaults to FileVersion.
		/// </remarks>
		[TaskAttribute("source", Required=false)]
		public string Source
		{
			get { return _source.ToString(); }
			set { _source = (VersionSource)Enum.Parse(typeof(VersionSource), value); }
		}

		/// <summary>
		/// Update File Version, Product Version or Both.
		/// </summary>
		/// <remarks>
		/// Possible values are FileVersion, ProductVersion or Both.
		/// </remarks>
		[TaskAttribute("update", Required=false)]
		public string Update
		{
			get { return _target.ToString(); }
			set { _target = (UpdateTypes)Enum.Parse(typeof(UpdateTypes), value); }
		}

		/// <summary>
		/// Sets a file to load the original version number from. 
		/// </summary>
		/// <remarks>
		/// This file must contain a version number in the form "major.minor.revision.build" 
		/// including the quotes on the first line. The rest of the contents of the file do 
		/// not matter. Settings this value automatically switches the source attribute
		/// to File.
		/// </remarks>
		[TaskAttribute("sourcefile", Required=false)]
		public string SourceFile
		{
			get { return _sourceFile; }
			set { _sourceFile = value; _source = VersionSource.File; }
		}

		/// <summary>
		/// The string value representing the product version number can be suffixed with this string.
		/// </summary>
		[TaskAttribute("productsuffix", Required=false)]
		public string ProductSuffix
		{
			get { return _productSuffix; }
			set { _productSuffix = value; }
		}

		/// <summary>
		/// The string value representing the file version number can be suffixed with this string.
		/// </summary>
		[TaskAttribute("filesuffix", Required=false)]
		public string FileSuffix
		{
			get { return _fileSuffix; }
			set { _fileSuffix = value; }
		}

		#region Increment Attributes

		/// <summary>
		/// Increments the major part of the version number by value. (major.minor.revision.build).
		/// </summary>
		[TaskAttribute("major", Required=false)]
		public int Major
		{
			get { return _incNumbers.major; }
			set { _incNumbers.major = value; }
		}

		/// <summary>
		/// Increments the minor part of the version number by value. (major.minor.revision.build).
		/// </summary>
		[TaskAttribute("minor", Required=false)]
		public int Minor
		{
			get { return _incNumbers.minor; }
			set { _incNumbers.minor = value; }
		}

		/// <summary>
		/// Increments the revision part of the version number by value. (major.minor.revision.build).
		/// </summary>
		[TaskAttribute("revision", Required=false)]
		public int Revision
		{
			get { return _incNumbers.revision; }
			set { _incNumbers.revision = value; }
		}

		/// <summary>
		/// Increments the build part of the version number by value. Defaults to 1. (major.minor.revision.build).
		/// </summary>
		[TaskAttribute("build", Required=false)]
		public int Build
		{
			get { return _incNumbers.build; }
			set { _incNumbers.build = value; }
		}

		#endregion

		#region Set Attributes

		/// <summary>
		/// Sets the major part of the version number (major.minor.revision.build).
		/// </summary>
		[TaskAttribute("setmajor", Required=false)]
		public int SetMajor
		{
			get { return _setNumbers.major; }
			set { _setNumbers.major = value; _setMask |= (int)VISetBits.Major; }
		}

		/// <summary>
		/// Sets the minor part of the version number (major.minor.revision.build).
		/// </summary>
		[TaskAttribute("setminor", Required=false)]
		public int SetMinor
		{
			get { return _setNumbers.minor; }
			set { _setNumbers.minor = value; _setMask |= (int)VISetBits.Minor; }
		}

		/// <summary>
		/// Sets the revision part of the version number (major.minor.revision.build).
		/// </summary>
		[TaskAttribute("setrevision", Required=false)]
		public int SetRevision
		{
			get { return _setNumbers.revision; }
			set { _setNumbers.revision = value; _setMask |= (int)VISetBits.Revision; }
		}

		/// <summary>
		/// Sets the build part of the version number (major.minor.revision.build).
		/// </summary>
		[TaskAttribute("setbuild", Required=false)]
		public int SetBuild
		{
			get { return _setNumbers.build; }
			set { _setNumbers.build = value; _setMask |= (int)VISetBits.Build; }
		}

		/// <summary>
		/// Sets the entire version number. 
		/// </summary>
		/// <remarks>
		/// Must be a valid version number string of the form: 
		/// major.minor.revision.build - e.g. "1.25.3.224". This disables
		/// all other update mechanisms.
		/// </remarks>
		[TaskAttribute("setversion", Required=false)]
		public string SetVersion
		{
			get { return _newVersionNum; }
			set { _newVersionNum = value; _setVersionNum = true; }
		}

		#endregion

		#endregion

		/// <summary>constructor</summary>
		public VersionInfoTask()
		{
			// By default, we will increment the build number by one.
			_incNumbers.major = _incNumbers.minor = _incNumbers.revision = 0;
			_incNumbers.build = 1;
		}

		/// <summary>
		/// This function fills in a VersionInfo class with values from a RegEx match.
		/// </summary>
		/// <param name="match">RegEx match with a,b,c and d named values for major.minor.revision.build.</param>
		/// <returns>VersionInfo class with values from the RegEx match.</returns>
		protected VersionInfo extractVersionInfo(Match match)
		{
			VersionInfo vi = new VersionInfo();

			vi.major	= Int32.Parse(match.Groups["a"].ToString());
			vi.minor	= Int32.Parse(match.Groups["b"].ToString());
			vi.revision = Int32.Parse(match.Groups["c"].ToString());
			vi.build	= Int32.Parse(match.Groups["d"].ToString());

			return vi;
		}

		/// <summary>
		/// If the regular expression (matcher) succeeds, then the version number 
		/// string is replaced with a new one.
		/// </summary>
		/// <param name="line">String to search.</param>
		/// <param name="matcher">Regular expression.</param>
		/// <param name="vi">New version number.</param>
		/// <param name="useCommas">Use commas or full-stops to separate.</param>
		/// <param name="suffix">Any string suffix required.</param>
		/// <returns>Updated string.</returns>
		protected string swapVersionTags(string line, Regex matcher, VersionInfo vi, bool useCommas, string suffix)
		{
			Match m = matcher.Match(line);
			if(m.Success)
			{
				vi.useCommas = useCommas;

				string replacestr = string.Format("${{1}}{0}{1}", vi.ToString(), suffix);
				if(m.Groups["end"].Length != 0)
					replacestr += "${end}";

				string ret = matcher.Replace(line, replacestr);
				return ret;
			}

			return line;
		}

		/// <summary>
		/// This searches for a version number in "infile" and returns a VersionInfo class on success.
		/// </summary>
		protected VersionInfo pass1(Regex matchregex)
		{
			Match m;
			VersionInfo vi = null;
			SimpleTextFile fIn = new SimpleTextFile(_fileName);

			fIn.Open();
			
			while(!fIn.EOF())
			{
				m = matchregex.Match(fIn.ReadLine());
				if(m.Success)
					vi = extractVersionInfo(m);
			}

			fIn.Close();
			
			return vi;
		}

		/// <summary>
		/// This function updates every version information reference in the VERSIONINFO block.
		/// </summary>
		protected void pass2(SimpleTextFile infile, SimpleTextFile outfile, VersionInfo vi)
		{
			string line;

			while(!infile.EOF())
			{
				line = infile.ReadLine();

				if(_target == UpdateTypes.FileVersion || _target == UpdateTypes.Both)
				{
					line = swapVersionTags(line, reFileVersion, vi, true, "");
					line = swapVersionTags(line, reFileVersionS2, vi, false, _fileSuffix);
				}				
				if(_target == UpdateTypes.ProductVersion || _target == UpdateTypes.Both)
				{
					line = swapVersionTags(line, reProductVersion, vi, true, "");
					line = swapVersionTags(line, reProductVersionS2, vi, false, _productSuffix);
				}

				outfile.WriteLine(line);
			}
		}

		/// <summary>
		/// If a build number file was used as the source, this will update that file.
		/// </summary>
		protected void updateBuildFile(SimpleTextFile infile, SimpleTextFile outfile, VersionInfo vi)
		{
			string line;

			while(!infile.EOF())
			{
				line = swapVersionTags(infile.ReadLine(), reCustomFileVersion, vi, false, "");
				outfile.WriteLine(line);
			}
		}

		/// <summary>
		/// Reads the original version number from a file.
		/// </summary>
		protected VersionInfo readNumberFile()
		{
			VersionInfo vi = null;

			SimpleTextFile fIn = new SimpleTextFile(_sourceFile);
			fIn.Open();

			if(!fIn.EOF())
			{
				Match m = reCustomFileVersion.Match(fIn.ReadLine());
				if(m.Success)
				{
					vi = extractVersionInfo(m);
				}
				fIn.Close();
			}
			
			return vi;
		}

		/// <summary>
		/// This function performs all of the updates to the version number read from a file.
		/// </summary>
		/// <param name="vi">Original Version Number.</param>
		/// <returns>Updated Version Number.</returns>
		protected VersionInfo updateVersionInfo(VersionInfo vi)
		{
			vi.major += _incNumbers.major;
			vi.minor += _incNumbers.minor;
			vi.revision += _incNumbers.revision;
			vi.build += _incNumbers.build;

			if(_setMask != 0)
			{
				// we have to set certain values.
				if((_setMask & (int)VISetBits.Major) != 0)
					vi.major = _setNumbers.major;
				if((_setMask & (int)VISetBits.Minor) != 0)
					vi.minor = _setNumbers.minor;
				if((_setMask & (int)VISetBits.Revision) != 0)
					vi.revision = _setNumbers.revision;
				if((_setMask & (int)VISetBits.Build) != 0)
					vi.build = _setNumbers.build;
			}

			return vi;
		}

		/// <summary>
		/// This function updates the file "fileName" using the delegate "fn".
		/// </summary>
		/// <param name="fileName">Name and path of the file to be updated.</param>
		/// <param name="vi">New version number.</param>
		/// <param name="fn">Delegate pointing to an update function.</param>
		public void updateFile(string fileName, VersionInfo vi, UpdateFunction fn)
		{
			string tempFileName = Path.GetTempFileName();
			
			SimpleTextFile fIn = new SimpleTextFile(fileName);
			SimpleTextFile fOut = new SimpleTextFile(tempFileName);

			fIn.Open();
			fOut.Open(true);
			try
			{
				fn(fIn, fOut, vi);
			}
			finally
			{
				fOut.Close();
				fIn.Close();
			}

			FileInfo finfo = new FileInfo(tempFileName);
			if(finfo.Exists)
			{
				try
				{
					System.IO.File.Delete(fileName);
					System.IO.File.Move(tempFileName, fileName);
				}
				catch( IOException ex )
				{
					throw new BuildException("Fatal Error: " + ex.Message, ex);
				}
			}
			else
				throw new BuildException("Error: Could not find (temporary) updated version file: " + tempFileName);
		}

		protected override void InitializeTask(System.Xml.XmlNode taskNode) 
		{
			FileInfo fi;

			if(FileName == null)
				throw new BuildException("Attribute \"filename\" is required.", Location);

			fi = new FileInfo(FileName);
			if(!fi.Exists)
				throw new BuildException("Version number file (" + FileName + ") does not exist, and cannot be updated.", Location);
			
			if(_source == VersionSource.File)
			{
				if(SourceFile == null)
					throw new BuildException("Attribute \"sourcefile\" must be a valid file when \"source\" is File", Location);

				fi = new FileInfo(SourceFile);
				if(!fi.Exists)
					throw new BuildException("Version number source file (" + SourceFile + ") does not exist.", Location);
			}
		}
        
		protected override void ExecuteTask()
		{
			VersionInfo vi = null;

			if(!_setVersionNum)
			{
				// Pass 1 simply looks for a version number to use as the base for an update.
				// We don't do this if there is an explicit new version number.

				switch(_source)
				{
					case VersionSource.FileVersion:
						vi = pass1(reFileVersion);
						break;
					case VersionSource.ProductVersion:
						vi = pass1(reProductVersion);
						break;
					case VersionSource.FileVersionString:
						vi = pass1(reFileVersionS);
						break;
					case VersionSource.ProductVersionString:
						vi = pass1(reProductVersionS);
						break;
					case VersionSource.File:
						vi = readNumberFile();
						break;
				}

				if(vi == null)
					throw new BuildException("No version number could be read from the input file.");

				vi = updateVersionInfo(vi);
			}
			else
			{
				// There is an explicit new version number.
				Match m = reSetVersionStr.Match(_newVersionNum);
				if(m.Success)
				{
					vi = extractVersionInfo(m);
				}
				else
					throw new BuildException("Could not find a correctly formed version number in: " + _newVersionNum);
			}

			updateFile(_fileName, vi, new UpdateFunction(pass2));

			if(_source == VersionSource.File)
				updateFile("build.number", vi, new UpdateFunction(updateBuildFile));
		}
	}
}
