// MKSSITask - MKS Source Integrity task.
// Copyright (C) 2003 Simon Steele (untidy.net)
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

using System;
using SourceForge.NAnt;
using SourceForge.NAnt.Tasks;
using SourceForge.NAnt.Attributes;

namespace Untidy.NAntTasks
{
	/// <summary>MKS Source Integrity Task</summary>
	/// <note>Currently only simple sandbox checkout functionality is implemented.</note>
	[TaskName("mkssi")]
	public class MKSSITask : ExternalProgramBase
	{
		enum MKSOperation
		{
			sandbox
		}

		enum MKSVolume
		{
			normal,
			quiet,
			terse
		}

		#region Private Members
		private MKSOperation _op = MKSOperation.sandbox;
		private MKSVolume _vol = MKSVolume.normal;
        private string _sandboxProjectFile = "sandbox.pj";
		private string _sandboxDir = null;
		private string _mksProject = null;
		private string _params = null;
		private string _revision = null;
		private bool _recursive = true;
		#endregion

		#region Task Attributes
		/// <summary>Directory in which to create the sandbox.</summary>
		/// <remarks>Valid for these CVS commands: sandbox. Default false.</remarks>
		[TaskAttribute("dir", Required=true)]
		public string Dir
		{
			get { return _sandboxDir; }
			set 
			{ 
				_sandboxDir = value;
				if(Project != null)
					_sandboxDir = Project.GetFullPath(_sandboxDir);
				if(_sandboxDir != null)
					if(_sandboxDir[_sandboxDir.Length - 1] != '\\')
						_sandboxDir += '\\';
			}
		}

		/// <summary>Path to SI project to work with.</summary>
		/// <example>\\mksserver\sources\myproject\project.pj</example>
		/// <remarks>Valid for these CVS commands: sandbox.</remarks>
		[TaskAttribute("project", Required=true)]
		public string MKSProject
		{
			get { return _mksProject; }
			set { _mksProject = value; }
		}

		/// <summary>Work with a specific project revision.</summary>
		/// <remarks>Valid for these CVS commands: sandbox. Default none.</remarks>
		[TaskAttribute("revision", Required=false)]
		public string Revision
		{
			get { return _revision; }
			set { _revision = value; }
		}

		/// <summary>Recurse into subdirectories.</summary>
		/// <remarks>Default true.</remarks>
		[TaskAttribute("recursive", Required=false)]
		public bool Recursive
		{
			get { return _recursive; }
			set { _recursive = value; }
		}

		/// <summary>Enable "quiet" mode.</summary>
		[TaskAttribute("quiet", Required=false)]
		public bool Quiet
		{
			get { return (_vol == MKSVolume.quiet); }
			set 
			{ 
				if(value) 
					_vol = MKSVolume.quiet; 
				else if(!value && _vol == MKSVolume.quiet) 
					_vol = MKSVolume.normal; 
			}
		}

		/// <summary>Enable "very quiet" mode.</summary>
		[TaskAttribute("veryquiet", Required=false)]
		public bool Terse
		{
			get { return (_vol == MKSVolume.terse); }
			set 
			{ 
				if(value) 
					_vol = MKSVolume.terse; 
				else if(!value && _vol == MKSVolume.terse) 
					_vol = MKSVolume.normal; 
			}
		}
		#endregion

		public override string ProgramFileName
		{
			get	{ return "pj"; }
		}

		public override string ProgramArguments 
		{
			get 
			{
				if(_params == null)
					throw new BuildException("Build parameters have not been initialised.");

				return _params;
			}
		}

		private string GetGeneralParameters()
		{
			string p = "";

			if(_vol == MKSVolume.quiet)
				p += " -q";
			else if(_vol == MKSVolume.terse)
				p += " -Q";

			if(_recursive)
				p += " -i";

			if(_revision != null)
				p += " -k " + _revision;

			// Add the master project parameter... (-P "MKSRoot\\master_project.pj")
			p += " -P \"" + _mksProject + "\"";

			// Add the sandbox parameter... (-S "c:\source\myproject\sandbox.pj")
			p += " -S \"" + _sandboxDir + _sandboxProjectFile + "\"";

			return p;
		}

		protected override void InitializeTask(System.Xml.XmlNode taskNode) 
		{

			if(_sandboxDir == null)
				throw new BuildException("Dir is a required attribute.", Location);

			if(_project == null)
				throw new BuildException("Project is a required attribute.", Location);

			string p = "";

			switch(_op)
			{
				case MKSOperation.sandbox:
					p = "sandbox";
					break;
			}

			p += " ";

			string generalopts = GetGeneralParameters();
			p += generalopts;

			_params = p;
		}
	}
}
