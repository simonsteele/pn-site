// InnoSetupTask - Simple wrapper for issc.exe, the InnoSetup command-line compiler.
// Copyright (C) 2003Simon Steele (untidy.net)
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

using System;
using System.IO;
using SourceForge.NAnt;
using SourceForge.NAnt.Tasks;
using SourceForge.NAnt.Attributes;
using Microsoft.Win32;

namespace Untidy.NAntTasks
{
	/// <summary>
	/// Calls the InnoSetup command-line compiler task.
	/// </summary>
	/// <remarks>
	///   <para>This task looks for a path to the compiler in three registry locations (until a path is found, ordered top-to-bottom):</para>
	///   <list type="table">
	///   <listheader>
	///   <term>Key</term>
	///   <description>Value</description>
	///   </listheader>
	///   <item><term>HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall\Inno Setup 3_is1</term><description>Inno Setup: App Path</description></item>
	///   <item><term>HKEY_LOCAL_MACHINE\Software\untidy.net\InnoSetupNAntTask</term><description>path</description></item>
	///   <item><term>HKEY_CURRENT_USER\Software\untidy.net\InnoSetupNAntTask</term><description>path</description></item>
	///   </list>
	///   <para>If the path is not found at any of these locations, it hopes that issc.exe is in the path.</para>
	///   <note>If the ISX or ISPP compilers are specified, the task will look in the following locations instead:</note>
	///   <list type="table">
	///   <listheader>
	///   <term>Key</term>
	///   <description>Value</description>
	///   </listheader>
	///   <item><term>HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Uninstall\My Inno Setup Extensions 3_is1</term><description>Inno Setup: App Path</description></item>
	///   <item><term>HKEY_LOCAL_MACHINE\Software\untidy.net\InnoSetupNAntTask</term><description>isxpath</description></item>
	///   <item><term>HKEY_CURRENT_USER\Software\untidy.net\InnoSetupNAntTask</term><description>isxpath</description></item>
	///   </list>
	/// </remarks>
	/// <example>
	///   <para>Compile <c>sample.iss</c> using the command-line compiler.</para>
	///   <code>&lt;iscompiler filename="sample.iss" /&gt;</code>
	///   <para>Compile <c>sample.iss</c> using the Inno Setup Pre-Processor compiler (isppcc.exe).</para>
	///   <code>&lt;iscompiler filename="sample.iss" compiler="ISPP" /&gt;</code>
	/// </example>
	[TaskName("iscompiler")]
	public class InnoSetupTask : ExternalProgramBase
	{
		enum InnoSetupCompiler
		{
			Default,
			ISX,
			ISPP
		}

		private string _fileName;
		private string _extraParams = "";
		private InnoSetupCompiler _compiler = InnoSetupCompiler.Default;

		/// <summary>
		/// Inno-Setup Script file (*.iss) to compile.
		/// </summary> 
		[TaskAttribute("script", Required=true)]
		public string FileName
		{
			get { return _fileName; }
			set { _fileName = value; }
		}

		/// <summary>
		/// Selects which (IS / ISX / ISPP) command-line compiler to use to compile the script.
		/// </summary>
		/// <remarks>
		/// Can take the following values : Default (default), ISX, ISPP. In the case that the 
		/// location of the compiler cannot be automatically determined, the compiler attribute
		/// cannot guarantee to select the correct compiler.
		/// </remarks>
		[TaskAttribute("compiler", Required=false)]
		public string Compiler
		{
			get { return _compiler.ToString(); }
			set { _compiler = (InnoSetupCompiler)Enum.Parse(typeof(InnoSetupCompiler), value); }
		}

		/// <summary>
		/// Allows the user to pass extra parameters to the compiler (useful for ISPP).
		/// </summary>
		[TaskAttribute("parameters", Required=false)]
		public string ExtraParams
		{
			get { return _extraParams; }
			set { _extraParams = value; }
		}

		private string GetInnoSetupPath(RegistryKey key, string subkey, string valuename)
		{
			RegistryKey thekey = key.OpenSubKey( subkey );
			if ( thekey == null ) 
				return null;

			object x = thekey.GetValue( valuename );
			if(x != null)
			{
				string p = (string)x;
				if(p[p.Length-1] != '\\')
					p += '\\';
				return p;
			}
			else
				return null;
		}

		// ExternalProgramBase implementation
		public override string ProgramFileName
		{
			get
			{
				string path;
				if(_compiler == InnoSetupCompiler.Default)
					path = GetInnoSetupPath(Registry.LocalMachine, "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Inno Setup 3_is1", "Inno Setup: App Path");
				else
					path = GetInnoSetupPath(Registry.LocalMachine, "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\My Inno Setup Extensions 3_is1", "Inno Setup: App Path");
				if(path == null)
				{
					string valname;
					if(_compiler == InnoSetupCompiler.Default)
						valname = "path";
					else
						valname = "isxpath";

					// try our own custom path...
					path = GetInnoSetupPath(Registry.LocalMachine, "Software\\untidy.net\\InnoSetupNAntTask", valname);
					if(path == null)
					{
						path = GetInnoSetupPath(Registry.CurrentUser, "Software\\untidy.net\\InnoSetupNAntTask", valname);
					}
				}
				
				string exe = "";
				if(path != null)
					exe = path;
				if(_compiler != InnoSetupCompiler.ISPP)
                    exe += "iscc.exe";
				else
					exe += "isppcc.exe";

				return exe;
			}
		}

		public override string ProgramArguments 
		{
			get 
			{
				return FileName + _extraParams;
			}
		}

		protected override void InitializeTask(System.Xml.XmlNode taskNode) 
		{
			if(FileName == null)
				throw new BuildException("Attribute \"script\" is required.", Location);

			FileInfo fi = new FileInfo(FileName);
			if(!fi.Exists)
				throw new BuildException("Inno Setup Script (" + FileName + ") does not exist.", Location);

		}
	}
}
