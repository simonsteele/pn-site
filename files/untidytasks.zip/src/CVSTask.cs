// CVSTask - CVS Task for NAnt.
// Copyright (C) 2003 Simon Steele (untidy.net)
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

namespace Untidy.NAntTasks
{
	using System;
	using System.IO;
	using SourceForge.NAnt;
	using SourceForge.NAnt.Tasks;
	using SourceForge.NAnt.Attributes;

	/// <summary>
	/// Carry out CVS operations.
	/// </summary>
	[TaskName("cvs")]
	public class CVSTask : ExternalProgramBase
	{
		enum CVSOperation
		{
			logon,
			checkout,
			update,
			tag
		};

		enum CVSServerType
		{
			ext,
			pserver,
			local
		};

		enum CVSVolume
		{
			normal,
			quiet,
			veryquiet
		};

		struct SCmdParts
		{
			public string command;
			public string commandParams;
			public bool needConnString;
		};

		#region Private Members
		private CVSOperation _op = CVSOperation.checkout;
		private CVSServerType _type = CVSServerType.pserver;
		private CVSVolume _vol = CVSVolume.normal;
		private string _params;
		private string _connString;
		private bool _overwriteLocal = false;
		private bool _recursive = false;
		private bool _noRecursion = false;
		private bool _forceHead = false;
		private bool _resetSticky = false;
		private bool _buildDirs = true;
		private bool _pruneDirs = true;
		private bool _noShorten = false;
		private bool _noModuleProgram = false;
		private string _date = null;
		private string _workDir = null;
		private string _dir = null;
		private string _module = null;
		private string _revision = null;
		private string _repository = null;
		private string _repositoryPath = null;
		private string _targetRevision = null;
		private string _userName = null;
		
		private string _controlParams = "-fz3";
		#endregion

		#region Task Attributes
		/// <summary>CVS Operation to carry out.</summary>
		/// <remarks>Possible values: checkout, update, tag.</remarks>
		[TaskAttribute("operation", Required=false)]
		public string Operation
		{
			get { return _op.ToString(); }
			set { _op = (CVSOperation)Enum.Parse(typeof(CVSOperation), value); }
		}

		/// <summary>CVS Server type.</summary>
		/// <remarks>Possible values: pserver, ext, local. Default: pserver</remarks>
		[TaskAttribute("connection", Required=false)]
		public string ServerType
		{
			get { return _type.ToString(); }
			set { _type = (CVSServerType)Enum.Parse(typeof(CVSServerType), value); }
		}

		/// <summary>CVS Server</summary>
		[TaskAttribute("server", Required=false)]
		public string Repository
		{
			get { return _repository; }
			set { _repository = value; }
		}

		/// <summary>PServer user name.</summary>
		[TaskAttribute("user", Required=false)]
		public string User
		{
			get { return _userName; }
			set { _userName = value; }
		}

		/// <summary>Remote Path (path to module)</summary>
		[TaskAttribute("remotepath", Required=false)]
		public string RemotePath
		{
			get { return _repositoryPath; }
			set { _repositoryPath = value; }
		}

		/// <summary>Module Name</summary>
		[TaskAttribute("module", Required=false)]
		public string Module
		{
			get { return _module; }
			set { _module = value; }
		}

		/// <summary>Full CVS Connection String.</summary>
		/// <remarks>e.g. :pserver:user@cvs.pnotepad.sourceforge.net:/cvsroot
		/// Makes server, username, ... redundant.</remarks>
		[TaskAttribute("connectionstring", Required=false)]
		public string ConnectionString
		{
			get { return _connString; }
			set { _connString = value; }
		}

		/// <summary>Overwrite locally modified files with clean repository versions.</summary>
		/// <remarks>Valid for these CVS commands: update. Default false.</remarks>
		[TaskAttribute("overwritelocal", Required=false)]
		public bool OverwriteLocal
		{
			get { return _overwriteLocal; }
			set { _overwriteLocal = value; }
		}

		/// <summary>Use a specific directory name instead of the module name.</summary>
		/// <remarks>Valid for these CVS commands: checkout. Default false.</remarks>
		[TaskAttribute("directory", Required=false)]
		public string LocalDirectory
		{
			get { return _dir; }
			set { _dir = value; }
		}

		/// <summary>Local directory in which to work.</summary>
		/// <remarks>Valid for these CVS commands: all. Default: project base directory.</remarks>
		[TaskAttribute("dir", Required=false)]
		public string WorkingDirectory
		{
			get { return _workDir; }
			set 
			{ 
				_workDir = value; 
				if(Project != null)
					_workDir = Project.GetFullPath(_workDir);
			}
		}

		/// <summary>Don't shorten module paths when checking out to a specific directory (-N).</summary>
		/// <remarks>Valid for these CVS commands: checkout. Default false.</remarks>
		[TaskAttribute("dontshorten", Required=false)]
		public bool NoShorten
		{
			get { return _noShorten; }
			set { _noShorten = value; }
		}

		/// <summary>Do not run module program (if any) (-n).</summary>
		/// <remarks>Valid for these CVS commands: checkout. Default false.</remarks>
		[TaskAttribute("nomodule", Required=false)]
		public bool NoModule
		{
			get { return _noModuleProgram; }
			set { _noModuleProgram = value; }
		}

		/// <summary>Use a specific revision/tag for CVS operations (-r).</summary>
		/// <remarks>Valid for these CVS commands: checkout, update.</remarks>
		[TaskAttribute("revision", Required=false)]
		public string Revision
		{
			get { return _revision; }
			set { _revision = value; }
		}

		/// <summary>Use a specific date for CVS operations (-D).</summary>
		/// <remarks>Valid for these CVS commands: checkout, update.</remarks>
		[TaskAttribute("date", Required=false)]
		public string Date
		{
			get { return _date; }
			set { _date = value; }
		}

		/// <summary>Revision to merge up to (-j).</summary>
		/// <remarks>Valid for these CVS commands: update.</remarks>
		[TaskAttribute("targetrevision", Required=false)]
		public string TargetRevision
		{
			get { return _targetRevision; }
			set { _targetRevision = value; }
		}

		/// <summary>Build directories like checkout does (-d).</summary>
		/// <remarks>Valid for these CVS commands: update. Default true.</remarks>
		[TaskAttribute("build", Required=false)]
		public bool BuildDirectories
		{
			get { return _buildDirs; }
			set { _buildDirs = value; }
		}

		/// <summary>Prune empty directories (-P).</summary>
		/// <remarks>Valid for these CVS commands: checkout, update. Default true.</remarks>
		[TaskAttribute("prune", Required=false)]
		public bool PruneDirectories
		{
			get { return _pruneDirs; }
			set { _pruneDirs = value; }
		}

		/// <summary>Process directories recursively (-R).</summary>
		/// <remarks>Valid for these CVS commands: checkout, update. Default false.</remarks>
		[TaskAttribute("recursive", Required=false)]
		public bool Recursive
		{
			get { return _recursive; }
			set { _recursive = value; }
		}

		/// <summary>Local directory only, not recursive (-l)</summary>
		/// <remarks>Valid for these CVS commands: checkout, update. Default false.</remarks>
		[TaskAttribute("norecursion", Required=false)]
		public bool NoRecursion
		{
			get { return _noRecursion; }
			set { _noRecursion = value; }
		}

		/// <summary>Force head revision if revision/tag not found (-f).</summary>
		/// <remarks>Valid for these CVS commands: checkout, update. Default false.</remarks>
		[TaskAttribute("forcehead", Required=false)]
		public bool ForceHead
		{
			get { return _forceHead; }
			set { _forceHead = value; }
		}
		
		/// <summary>Reset any sticky tags etc (-A).</summary>
		/// <remarks>Valid for these CVS commands: checkout, update. Default false.</remarks>
		[TaskAttribute("resetsticky", Required=false)]
		public bool ResetSticky
		{
			get { return _resetSticky; }
			set { _resetSticky = value; }
		}

		/// <summary>Cause CVS to be somewhat quiet.</summary>
		[TaskAttribute("quiet", Required=false)]
		public bool Quiet
		{
			get { return (_vol == CVSVolume.quiet); }
			set 
			{ 
				if(value) 
					_vol = CVSVolume.quiet; 
				else if(!value && _vol == CVSVolume.quiet) 
					_vol = CVSVolume.normal; 
			}
		}

		/// <summary>Cause CVS to be really quiet.</summary>
		[TaskAttribute("veryquiet", Required=false)]
		public bool VeryQuiet
		{
			get { return (_vol == CVSVolume.veryquiet); }
			set 
			{ 
				if(value) 
					_vol = CVSVolume.veryquiet; 
				else if(!value && _vol == CVSVolume.veryquiet) 
					_vol = CVSVolume.normal; 
			}
		}

		#endregion

		public override string ProgramFileName
		{
			get	{ return Name; }
		}

		public override string ProgramArguments 
		{
			get 
			{
				if(_params == null)
					throw new BuildException("Build parameters have not been initialised.");

				return _params;
			}
		}

		public override string BaseDirectory 
		{ 
			get 
			{
				if(_workDir != null)
				{
					DirectoryInfo di = new DirectoryInfo(_workDir);

					if(! di.Exists )
						di = Directory.CreateDirectory(_workDir);

					if(di.Exists)
						return _workDir;
					else
						return base.BaseDirectory;
				}
				else
					return base.BaseDirectory;
			}
		}

		private SCmdParts BuildOperationOptions()
		{
			SCmdParts s = new SCmdParts();
			s.commandParams = "-";

			if(_op == CVSOperation.checkout || _op == CVSOperation.update)
			{
				if(_pruneDirs)
					s.commandParams += "P";
				if(_noRecursion)
					s.commandParams += "l";
				if(_forceHead)
					s.commandParams += "f";
				if(_recursive)
					s.commandParams += "R";
				if(_resetSticky)
					s.commandParams += "A";

				if(_op == CVSOperation.checkout)
				{
					if(_noShorten)
						s.commandParams += "N";
					if(_noModuleProgram)
						s.commandParams += "n";
				}
				else if(_op == CVSOperation.update)
				{
					if(_buildDirs)
						s.commandParams += "d";
					if(_overwriteLocal)
						s.commandParams += "C";
				}

				if(_date != null)
					s.commandParams += " -D " + _date;

				if(_revision != null)
					s.commandParams += " -r " + _revision;

				if(_targetRevision != null)
					s.commandParams += " -j " + _targetRevision;

				if(_op == CVSOperation.checkout)
				{
					if(_dir != null)
						s.commandParams += " -d " + _dir;
				}
			}

			switch(_op)
			{
				case CVSOperation.checkout:
				{
					s.needConnString = true;
					
					if(_module == null)
						throw new BuildException("The module attribute must be specified for a checkout.");
					
					s.command = "checkout";
					s.commandParams += " " + _module;
				}
				break;

				case CVSOperation.update:
					s.needConnString = false;	// should already have a server path.
					s.command = "update";
					break;
			}

			return s;
		}

		protected override void InitializeTask(System.Xml.XmlNode taskNode) 
		{
			// Set up the parameters...
			SCmdParts opts = BuildOperationOptions();

			if(_vol == CVSVolume.quiet)
				_controlParams += " -q";
			if(_vol == CVSVolume.veryquiet)
				_controlParams += " -Q";

			_params = _controlParams + " ";

			if(opts.needConnString)
			{
				// Build up a connection string, and include it in the command.
				if(_connString != null)
				{
					_params += string.Format("-d{0} ", _connString);
				}
				else
				{
					if(_userName == null || _repository == null || _repositoryPath == null)
					{
						string err = string.Format("A connection string is required for the {0} operation, " +
							"and one of the following arguments was not provided: " +
							"server, remotepath, username.",
							_op.ToString());
						throw new BuildException(err);
					}

					_params += string.Format("-d:{0}:{1}@{2}:{3} ", _type.ToString(), _userName, _repository, _repositoryPath);
				}
			}

			_params += opts.command + " " + opts.commandParams;

			Log.WriteLine(LogPrefix + "CVS Parameters: {0}", _params);
		}
	}
}
