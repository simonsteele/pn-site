Borland Delphi control wrapper for Scintilla version 1.4
=========================================================
Scintilla (www.scintilla.org) is a free source code editing component. It comes 
with complete source code and a license that permits use in any free or 
commercial product. 

Main features:
- Syntax hilighting for over 30 languages
- Unicode support
- Code folding and zooming 
- Autocompletion, parameter tips etc.
- Available for Linux and Windows


This Delphi wrapper was originally written by Simon Steele (www.pnotepad.org)
Substantial changes (hopefully improvements) were introduced by the author 
(Kiriakos Vlahos - kvlahos@london.edu) the most important of which are:
- exposed a large number of Scintilla features including syntax highlighting
  keywords and styles as component properties
- automated the setting of keywords and styles for the most common languages 
- modified the editor so that it is active at design time
- wrote a design and runtime editor options customization form
- added a component for search and replace based on the Synedit(synedit.sourceforge.com)
- wrote a full-featured demo demonstrating the most interesting aspects of 
  Scintilla
- wrote a help file

Installation for D6 and D7
==========================
- Download the Scintilla.dll from www.scintilla.org and put it somewhere on the
  system path. 
- Expand the zip file onto a folder of your choice
- In Delphi open and install the appropriate package file (*.dpk)
- The component editor uses some components from the JVCL collection. You can download it from http://jvcl.sourceforge.net.  Alternatively, if you do not wish to use the design and run-time options dialog, remove the EdOptionsWin.pas and SciLexerDlg.pas files from the package and modify SciLexerReg.pas accordingly.
- Have a look at the demo to see how the component is used (no help file provided).




====================================================================================

Contents of readme.txt of version 1.0b by Simon Steele (www.pnotepad.org)

Borland Delphi control wrapper for Scintilla version 1.0b
=========================================================

Scintilla is a fairly standard windowed control and this wrapper is also fairly 
simple - most of it is automatically generated using python scripts which can be
downloaded from www.pnotepad.org/scintilla/. 

This control can be placed on the form at design time, but will not work until 
the program is actually running (yet). Also, very few properties are actually 
surfaced, everything must be set using the standard scintilla methods - all of 
which are wrapped by the control. 

Finally, note that the SetFocus method of Scintilla is SetFocusEx for the wrapper 
because SetFocus is a useful method of TWinControl from which TScintilla derives.

note:: you cannot configure the control until it's window has been created - you 
will cause a crash otherwise.

It is not possible to use the scintilla control in design mode, although you can
place it on a form.

New:
====

Also included in this release is a Delphi implementation of the Accessor class,
and a package file for Delphi 6. 

Fixes:
======

1. Flickering on Resize and Scroll (Again) - removed WM_ERASEBKGND, thanks to
   Gertjan Schuurmans and Jeff Cogswell.
2. Incorrect re-drawing when scrolling horizontally fixed, re-instated CS_HREDRAW
   and CS_VREDRAW.

Last Built:
===========
Last refreshed against scintilla 1.56.